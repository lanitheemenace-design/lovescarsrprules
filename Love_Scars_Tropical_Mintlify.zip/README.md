# Love Scars RP — Mintlify starter

Branded documentation site for Love Scars RP. The uploaded logo is included under `images/`.

## Publish

1. Create a new GitHub repository and upload the **contents** of this folder (keep `docs.json` at the repository root).
2. In the Mintlify dashboard, create a documentation project and connect that repository.
3. Follow Mintlify's deployment prompts. If you prefer local preview, install the Mintlify CLI according to the current official docs and run it in this folder.
4. Edit each `.mdx` file to replace **Coming soon** placeholders with approved Love Scars policies and links.
5. Commit changes to GitHub to trigger redeployment.

## Notes

- `docs.json` configures navigation, colors, logo, and dark mode.
- `index.mdx` is the homepage.
- No Discord invitation, server IP, policy, or business prices have been invented.
- If Mintlify reports a configuration validation error, check the current `docs.json` schema at https://mintlify.com/docs/organize/settings and update the affected field.

## Vibrant theme
Electric pink accents and a crimson-pink-gold gradient homepage. Edit `docs.json` and `index.mdx` to customize.

## Tropical update
The homepage now uses `images/tropical-love-scars-bg.svg` with lush green leaves, pink flowers and golden vines, inspired by the uploaded logo (no palm trees). Edit `index.mdx` to change the hero background.
